//
//  Model.swift
//  20.11_MVCAdvanced
//
//  Created by Dominique Nascimento Bezerra on 20/11/20.
//

import Foundation

class Model: BaseClass {
    
}
